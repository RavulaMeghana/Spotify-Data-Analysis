# Spotify-Data-Analysis

This project on Spotify Data Analysis Project will teach how to perform exploratory data analysis using Python on music related datasets.
Spotify is the world's largest audio streaming platform. You will learn how to analyze, visualize and draw insights with Python libraries and functions.

We will perform the Spotify Data Analysis using the Jupyter notebook. To perform data analysis, we need to download the Spotify dataset.
The datasets are downloaded from kaggle. You can visit the mentioned links and download your copies of the datasets.
After downloading the dataset, we will launch the Jupyter notebook and install the following libraries: pandas, numpy, matplotlib and seaborn.
and try different methods to analyze, visualize and draw insights with Python libraries and functions.
Dataset:
https://www.kaggle.com/datasets/lehaknarnauli/spotify-datasets?select=artists.csv
